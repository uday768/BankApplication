package com.suncorp.banking.application.validation.groups;

public interface NullNotAllowed {

}
